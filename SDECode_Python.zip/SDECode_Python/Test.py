from NISDE import *
from ParEst import *
from Hom import *
import matplotlib.pyplot as plt
import sys
from multiprocessing import Pool
import functools
from scipy.special import gamma
from scipy.stats import norm

sigmaVec = [.5]
betaVec = [5]

# Set up the equation
eps = 0.05
sde = MSOrnUhl(eps)
sdeHomo = OrnUhl()
EM = EulerMaruyama(sde)

for sigma in sigmaVec:

    alpha = 1.0
    param = np.array([alpha, sigma])
    IC = 0.0

    # Compute the homogenized coefficients
    hom_param = compute_homogeneous(param, 2.0 * np.pi, sde.p)
    print(hom_param)

    np.savetxt("../SDECode/matlabPlots/ParameterEstimation/resultsQU_epsBig2/ResultsHom" + "_s" + str(sigma) + ".txt", hom_param, fmt='%f')

    for betaFilter in betaVec:

        # Set parameters
        gammaTime = 2.0
        beta = 2.5
        T = round(eps ** (-1.0 * gammaTime))
        h = eps ** beta

        nZeta = 11
        zMax = 1.0
        zIncrement = zMax / (nZeta - 1)

        A_filt_means = np.zeros(nZeta)
        A_filt_stds = np.zeros(nZeta)
        A_sub_means = np.zeros(nZeta)
        A_sub_stds = np.zeros(nZeta)
        S_filt_means = np.zeros(nZeta)
        S_filt_stds = np.zeros(nZeta)
        S_sub_means = np.zeros(nZeta)
        S_sub_stds = np.zeros(nZeta)

        supnSub = int(eps**(1.0-beta))+1
        infnSub = int(eps**(-beta))
        nSubRange = np.logspace(-1.0*beta, 1.0-beta, num=nZeta, base=eps)

        for i in range(0, 1):

            N = int(round(T/h))
            # print('T = ', T, 'h = ', h, 'N = ', round(T/h))
            # print i*zIncrement

            zetaSub = 2.0/3  # beta + np.log(nSubRange[i]) / np.log(eps)
            zetaFilter = zetaSub

            deltaSub = eps ** zetaSub
            nSub = int(deltaSub/h) #int(nSubRange[i])
            deltaFilter = eps ** zetaFilter
            tVec = np.arange(N+1) * h

            # Initialize results
            nExp = 1000

            def in_loop(seed, tilde=False, plot=False):
                print seed
                # Generate solution
                y, dw = EM.solve(IC, N, T, param, seed=seed)
                sub = y[::nSub]
                par_est_sub = ParEst(sub, sdeHomo.grad_v_vect, deltaSub, is_vect=True)
                filt, kt = filter_trajectory(y, deltaFilter, T, beta=betaFilter, type=0)  # grad=sdeHomo.grad_v_vect)
                par_est_filt = ParEst(filt, sdeHomo.grad_v_vect, h, is_vect=True)
                if tilde:
                    a_fi, s_fi = par_est_filt.drift_alternative(sdeHomo.lapl_v_vect, delta=kt*h/(2.0**(1.0/betaFilter)))
                    a_sub = par_est_sub.drift()
                    s_sub = par_est_sub.diffusion()
                    # a_sub, s_sub = par_est_sub.drift_alternative(sdeHomo.lapl_v_vect)
                else:
                    s_fi = par_est_filt.diffusion() / (kt * h / (2.0 ** (1.0 / betaFilter)))
                    c_b = betaFilter / gamma(1.0 / betaFilter)
                    a_fi = par_est_filt.drift()
                    # a_fi2, dummy = par_est_filt.formula_verification(param[1], param[0], p=sde.p,
                    #                                               eps=eps, delta=deltaFilter, data=y,
                    #                                               dW=dw, beta=betaFilter)
                    s_sub = par_est_sub.diffusion()
                    a_sub = par_est_sub.drift()
                    # par_est_sub.formula_verification_subs(param[1], param[0], p=sde.p, eps=eps,
                    #                                     data=y[0:1+nSub*(np.size(sub)-1)], dW=dw)

                if plot and seed == 0:
                    plt.plot(y)
                    plt.plot(filt)
                    plt.show()

                return a_sub, s_sub, a_fi, s_fi

            p = Pool(min(nExp, 11))
            results = p.map(functools.partial(in_loop, tilde=True, plot=False), range(nExp))
            aSub, sSub, aFilt, sFilt = np.asarray(zip(*results))
            p.close()

            res = np.sort(np.sqrt(T) * (aFilt - hom_param[0]))
            plt.hist(res, density=True, alpha=0.5, bins=20)
            # plt.axvline(x=hom_param[0])
            plt.plot(res, norm.pdf(res, 0, res.std()))
            plt.plot(res, norm.pdf(res, 0, np.sqrt(2*hom_param[0])))
            plt.show()

            res = np.sort(np.sqrt(T) * (aSub - hom_param[0]))
            plt.hist(res, density=True, alpha=0.5, bins=20)
            # plt.axvline(x=hom_param[0])
            plt.plot(res, norm.pdf(res, 0, res.std()))
            plt.plot(res, norm.pdf(res, 0, np.sqrt(2*hom_param[0])))
            plt.show()

            res = np.sort(np.sqrt(T) * (sFilt - hom_param[1]))
            plt.hist(res, density=True, alpha=0.5, bins=20)
            # plt.axvline(x=hom_param[1])
            plt.plot(res, norm.pdf(res, 0, res.std()))
            plt.show()

            res = np.sort(np.sqrt(T) * (sSub - hom_param[1]))
            plt.hist(res, density=True, alpha=0.5, bins=20)
            # plt.axvline(x=hom_param[1])
            plt.plot(res, norm.pdf(res, 0, res.std()))
            plt.show()

            A_filt_means[i] = aFilt.mean()
            A_filt_stds[i] = aFilt.std()
            A_sub_means[i] = aSub.mean()
            A_sub_stds[i] = aSub.std()
            S_filt_means[i] = sFilt.mean()
            S_filt_stds[i] = sFilt.std()
            S_sub_means[i] = sSub.mean()
            S_sub_stds[i] = sSub.std()

            print(['hom: ', 'A ', hom_param[0], 'S ', hom_param[1]])
            print(['fil: ', 'A ', aFilt.mean(), aFilt.std(), 'S ', sFilt.mean(), sFilt.std()])
            print(['sub: ', 'A ', aSub.mean(), aSub.std(), 'S ', sSub.mean(), sSub.std()])

        # Write data to file
        np.savetxt("../SDECode/matlabPlots/ParameterEstimation/resultsQU_epsBig2/ResultsFilter" + "_s" + str(sigma) + "_b" + str(betaFilter) + ".txt", np.append(A_filt_means, A_filt_stds), fmt='%f')
    np.savetxt("../SDECode/matlabPlots/ParameterEstimation/resultsQU_epsBig2/ResultsSub"+ "_s" + str(sigma) + ".txt" , np.append(A_sub_means, A_sub_stds), fmt='%f')



# A_filt_sorted, A_filt_density = get_density(A_filt)
# A_full_sorted, A_full_density = get_density(A_full)
# A_sub_sorted, A_sub_density = get_density(A_sub)
#
# plt.hist(A_filt, bins=30, density=True, alpha=0.5)
# plt.hist(A_sub, bins=30, density=True, alpha=0.5)
# # plt.hist(A_full, bins=30, density=True, alpha=0.5)
# plt.plot(A_filt_sorted, A_filt_density)
# plt.plot(A_sub_sorted, A_sub_density)
# # plt.plot(A_full_sorted, A_full_density)
# plt.axvline(x=hom_param[0])
# plt.axvline(x=param[0])
# plt.legend(['filt', 'subsam'])
# plt.show()
#
# S_filt_sorted, S_filt_density = get_density(S_filt)
# S_sub_sorted, S_sub_density = get_density(S_sub)
# S_full_sorted, S_full_density = get_density(S_full)
#
# plt.hist(S_filt, bins=30, density=True, alpha=0.5)
# plt.hist(S_sub, bins=30, density=True, alpha=0.5)
# # plt.hist(S_full, bins=30, density=True, alpha=0.5)
# plt.plot(S_filt_sorted, S_filt_density)
# plt.plot(S_sub_sorted, S_sub_density)
# # plt.plot(S_full_sorted, S_full_density)
# plt.axvline(x=hom_param[1])
# plt.axvline(x=param[1])
# plt.legend(['filt', 'subsam']) #, 'full'])
# plt.show()
#
# zetaVec = np.linspace(0.0, zMax, nZeta)
# plt.plot(zetaVec, A_filt_means, 'b')
# plt.plot(zetaVec, A_filt_means + 2.0*A_filt_stds, 'b--')
# plt.plot(zetaVec, A_filt_means - 2.0*A_filt_stds, 'b--')
# plt.plot(zetaVec, A_sub_means, 'r')
# plt.plot(zetaVec, A_sub_means + 2.0*A_sub_stds, 'r--')
# plt.plot(zetaVec, A_sub_means - 2.0*A_sub_stds, 'r--')
# plt.plot(zetaVec, hom_param[0] * np.ones(nZeta), 'k--')
# plt.show()
#
# zetaVec = np.linspace(0.0, zMax, nZeta)
# plt.plot(zetaVec, S_filt_means, 'b')
# plt.plot(zetaVec, S_filt_means + 2.0*S_filt_stds, 'b--')
# plt.plot(zetaVec, S_filt_means - 2.0*S_filt_stds, 'b--')
# plt.plot(zetaVec, S_sub_means, 'r')
# plt.plot(zetaVec, S_sub_means + 2.0*S_sub_stds, 'r--')
# plt.plot(zetaVec, S_sub_means - 2.0*S_sub_stds, 'r--')
# plt.plot(zetaVec, hom_param[1] * np.ones(nZeta), 'k--')
# plt.show()


# np.savetxt("../SDECode/matlabPlots/ParameterEstimation/ResultsFilterHom.txt", hom_param, fmt='%f')
# np.savetxt("../SDECode/matlabPlots/ParameterEstimation/ResultsFilter.txt", A_filt, fmt='%f')
# np.savetxt("../SDECode/matlabPlots/ParameterEstimation/ResultsFilterSubs.txt", A_sub, fmt='%f')
# np.savetxt("../SDECode/matlabPlots/ParameterEstimation/ResultsFilterFull.txt", A_full, fmt='%f')
#
# np.savetxt("../SDECode/matlabPlots/ParameterEstimation/ResultsFilterDiff.txt", S_filt, fmt='%f')
# np.savetxt("../SDECode/matlabPlots/ParameterEstimation/ResultsFilterSubsDiff.txt", S_sub, fmt='%f')
# np.savetxt("../SDECode/matlabPlots/ParameterEstimation/ResultsFilterFullDiff.txt", S_full, fmt='%f')