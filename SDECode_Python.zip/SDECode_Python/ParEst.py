import numpy as np
import scipy.stats as stats
from scipy.signal import convolve
from scipy.special import gamma
import matplotlib.pyplot as plt


def moving_average(a, n):
    ret = np.zeros(np.size(a))
    for i in range(0, n):
        ret[i] = ret[i-1] + (a[i] - a[0]) / n
    for i in range(n, np.size(ret)):
        ret[i] = ret[i-1] + (a[i] - a[i-n]) / float(n)
    return ret


def filter_trajectory(a, delta, T, beta=1, type=0):
    n = np.size(a)
    h = T / (n-1)
    t_vec = np.arange(n) * h
    c_beta = beta / gamma(1.0/beta)
    # k = c_beta * np.exp(-1.0 * (t_vec ** beta) / delta) / (delta ** (1.0 / beta))
    if type == 0:
        k = c_beta * np.exp(-1.0 * (t_vec / delta) ** beta) / delta
    else:
        k = c_beta/delta - c_beta/(delta**(beta+1))*(t_vec**beta)
        k[k < 0] = 0

    # The two lines below are equivalent to
    # ret = np.zeros(n)
    # for i in range(0, n):
    #     for j in range(0, i):
    #         ret[i] += k[i-j] * a[j]
    # ret *= h

    ret = convolve(a, k, mode='full') * h
    ret = ret[0:n]

    return ret, k[0]


def get_density(x):
    kde = stats.gaussian_kde(x)
    x_sorted = np.sort(x)
    density = kde.evaluate(x_sorted)
    return x_sorted, density


class ParEst:
    def __init__(self, x, grad_v, h, is_vect=False):
        self.x = x
        self.grad_v = grad_v
        self.h = h
        self.x_diff = np.diff(x)
        self.n = np.size(x)
        self.is_vect = is_vect

    def phi_prime(self, y):
        return self.period / self.zHat * np.exp(self.p(y) / self.sigma) - 1.0

    def phi(self, y):
        n_grid = 10
        grid = np.linspace(0.0, y, n_grid+1)
        dx_integral = y / n_grid
        func = np.exp(self.p(grid) / self.sigma)
        return self.period / self.zHat * np.trapz(func, dx=dx_integral) - y

    @staticmethod
    def dsk(delta, t, s, beta):
        c_beta = beta / gamma(1.0/beta)
        # if t-s > delta:
        #     return 0
        # return beta * c_beta * (t - s)**(beta - 1) * delta**(-1.0 * (beta + 1))
        return c_beta / (delta ** (beta+1)) * beta * ((t-s)**(beta-1)) * np.exp(-1.0 * ((t - s) / delta) ** beta)

    @staticmethod
    def ker(delta, t, s, beta):
        c_beta = beta / gamma(1.0/beta)
        # if t-s > delta:
        #     return 0
        # return c_beta/delta - c_beta/(delta**(beta-1)) * (t-s)**beta
        return c_beta / delta * np.exp(-1.0 * ((t - s) / delta) ** beta)

    def formula_verification(self, sigma, alpha, p=None, eps=1, delta=1, data=None, dW=None, beta=1):

        self.p = p
        self.sigma = sigma
        self.period = 2.0*np.pi

        # Compute ZHat for the definition of Phi and its derivative
        nZIntegral = 10000
        zIntX = np.linspace(0.0, self.period, nZIntegral+1)
        zIntdx = self.period / nZIntegral
        p_eval = p(zIntX)
        integrandZHat = np.exp(p_eval / sigma)
        self.zHat = np.trapz(integrandZHat, dx=zIntdx)

        tVec = self.h * np.arange(self.n)

        gradEval = self.grad_v(self.x[0:-1])
        phiEval = np.zeros(self.n)
        phiEval[0] = self.phi(data[0] / eps)
        onePlusPhiPrime = np.zeros(self.n)
        onePlusPhiPrime[0] = 1.0 + self.phi_prime(data[0] / eps)
        innerStochIntegral = np.zeros(self.n)
        innerDetIntegral = np.zeros(self.n)

        for i in range(1, self.n):
            phiEval[i] = self.phi(data[i]/eps)
            onePlusPhiPrime[i] = 1.0 + self.phi_prime(data[i] / eps)
            innerDetIntegral[i] = innerDetIntegral[i-1] + self.h * self.grad_v(data[i-1]) * onePlusPhiPrime[i-1]
            innerStochIntegral[i] = innerStochIntegral[i-1] + dW[i-1] * onePlusPhiPrime[i-1]

        integrand1 = np.zeros(self.n-1)
        integrand2 = np.zeros(self.n-1)
        integrand3 = np.zeros(self.n-1)
        window = 2*int(delta / self.h)

        for i in range(0, self.n-1):
            # beginIdx = max(0, i-window)
            # for j in range(beginIdx, i):
            for j in range(0, i):
                dsk_eval = self.dsk(delta, tVec[i], tVec[j], beta)
                integrand1[i] += self.h * dsk_eval * (innerDetIntegral[i] - innerDetIntegral[j])
                integrand2[i] += self.h * dsk_eval * (innerStochIntegral[i] - innerStochIntegral[j])
                integrand3[i] += self.h * dsk_eval * (phiEval[i] - phiEval[j])

        otherTerm = 0.0
        for i in range(0, self.n-1):
            otherTerm += self.h * gradEval[i] * self.ker(delta, tVec[i], 0, beta) * data[i]

        integral1 = alpha * self.h * np.sum(np.multiply(integrand1, gradEval))
        integral2 = np.sqrt(2.0*sigma) * self.h * np.sum(np.multiply(integrand2, gradEval))
        integral3 = eps * self.h * np.sum(np.multiply(integrand3, gradEval))

        denom = np.sum(gradEval**2) * self.h
        first_term = integral1 / denom
        second_term = -integral2 / denom
        third_term = integral3 / denom
        fourth_term = otherTerm / denom
        print first_term, second_term, third_term, fourth_term, first_term+second_term+third_term+fourth_term

        return first_term+second_term+third_term+fourth_term, second_term

    def formula_verification_subs(self, sigma, alpha, p=None, eps=1, data=None, dW=None):

        self.p = p
        self.sigma = sigma
        self.period = 2.0 * np.pi
        N = np.size(data)
        T = self.h * (self.n-1)
        hData = T / (N-1)
        nSubs = int(round(self.h / hData))

        # Compute ZHat for the definition of Phi and its derivative
        nZIntegral = 10000
        zIntX = np.linspace(0.0, self.period, nZIntegral + 1)
        zIntdx = self.period / nZIntegral
        p_eval = p(zIntX)
        integrandZHat = np.exp(p_eval / sigma)
        self.zHat = np.trapz(integrandZHat, dx=zIntdx)

        gradEval = self.grad_v(data)
        onePlusPhiPrime = np.zeros(N)
        onePlusPhiPrime[0] = 1.0 + self.phi_prime(data[0] / eps)
        innerStochIntegral = np.zeros(N)
        innerDetIntegral = np.zeros(N)

        for i in range(1, N):
            onePlusPhiPrime[i] = 1.0 + self.phi_prime(data[i] / eps)
            innerDetIntegral[i] = innerDetIntegral[i-1] + hData * gradEval[i-1] * onePlusPhiPrime[i-1]
            innerStochIntegral[i] = innerStochIntegral[i-1] + dW[i-1] * onePlusPhiPrime[i-1]

        firstTerm = np.zeros(self.n-1)
        secondTerm = np.zeros(self.n-1)
        thirdTerm = np.zeros(self.n-1)

        for i in range(0, self.n-1):
            idxLow = i*nSubs
            idxHigh = (i+1)*nSubs
            firstTerm[i] = innerDetIntegral[idxHigh] - innerDetIntegral[idxLow]
            secondTerm[i] = innerStochIntegral[idxHigh] - innerStochIntegral[idxLow]
            thirdTerm[i] = self.phi(data[idxHigh] / eps) - self.phi(data[idxLow] / eps)
            print(-alpha * firstTerm[i] + np.sqrt(2.0*sigma) * secondTerm[i] - eps * thirdTerm[i], self.x[i+1] - self.x[i])

        gradEvalSubs = self.grad_v(self.x[0:-1])
        firstTermSum = alpha * np.sum(np.multiply(firstTerm, gradEvalSubs))
        secondTermSum = np.sqrt(2.0 * sigma) * np.sum(np.multiply(secondTerm, gradEvalSubs))
        thirdTermSum = eps * np.sum(np.multiply(thirdTerm, gradEvalSubs))

        denom = np.sum(gradEvalSubs ** 2) * self.h
        firstTermFinal = firstTermSum / denom
        secondTermFinal = -secondTermSum / denom
        thirdTermFinal = thirdTermSum / denom
        print firstTermFinal, secondTermFinal, thirdTermFinal, firstTermFinal + secondTermFinal + thirdTermFinal
        return firstTermFinal

    def drift(self, strat=False, Sigma=1, lapl=None):
        if self.is_vect:
            grad_v_eval = self.grad_v(self.x[0:-1])
        else:
            grad_v_eval = np.zeros(self.n - 1)
            for i in range(0, self.n - 1):
                grad_v_eval[i] = self.grad_v(self.x[i])
        num_summand = np.multiply(self.x_diff, grad_v_eval)
        num = np.sum(num_summand)
        if strat:
            correction = Sigma * self.h * np.sum(lapl(self.x[0:-1]))
            num -= correction
        den = np.sum(np.square(grad_v_eval))
        return -1.0 * num / (self.h * den)

    def drift_alternative(self, lapl, delta=1.0, sigma=0):
        if sigma == 0:
            sigma = self.diffusion() / delta
        grad_v_eval = self.grad_v(self.x[0:-1])
        den = np.sum(np.square(grad_v_eval)) * self.h
        num = sigma * np.sum(lapl(self.x[0:-1])) * self.h
        return num / den, sigma

    def diffusion(self):
        return np.sum(np.square(self.x_diff)) / (2.0 * self.h * self.n)

    def drift_bayesian(self, a_pr, var_pr):
        grad_v_eval = np.zeros(self.n - 1)
        if self.is_vect:
            grad_v_eval = self.grad_v(self.x[0:-1])
        else:
            for i in range(0, self.n - 1):
                grad_v_eval[i] = self.grad_v(self.x[i])
        int_num = np.sum(np.multiply(self.x_diff, grad_v_eval))
        int_denom = self.h * np.sum(np.square(grad_v_eval))
        den = 1.0 + var_pr**2.0 * int_denom
        num = a_pr - var_pr**2.0 * int_num
        a_post = num / den
        var_post = 1.0 / (var_pr**(-2.0) + int_denom)
        return a_post, var_post
